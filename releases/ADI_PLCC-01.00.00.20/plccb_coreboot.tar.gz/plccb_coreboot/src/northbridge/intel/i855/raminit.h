/*
 * This file is part of the coreboot project.
 *
 * Copyright (C) 2006 Jon Dufresne <jon.dufresne@gmail.com>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 */

#ifndef NORTHBRIDGE_INTEL_I855_RAMINIT_H
#define NORTHBRIDGE_INTEL_I855_RAMINIT_H

/* i855 Northbridge PCI devices */
#define NORTHBRIDGE         PCI_DEV(0, 0, 0)
#define NORTHBRIDGE_MMC     PCI_DEV(0, 0, 1)

/* The i855 supports max. 2 dual-sided SO-DIMMs. */
#define DIMM_SOCKETS 2

void sdram_initialize(void);

#endif /* NORTHBRIDGE_INTEL_I855_RAMINIT_H */
