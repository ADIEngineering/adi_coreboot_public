#ifndef PC80_KEYBOARD_H
#define PC80_KEYBOARD_H

void pc_keyboard_init(void);
void set_kbc_ps2_mode(void);

#endif /* PC80_KEYBOARD_H */
