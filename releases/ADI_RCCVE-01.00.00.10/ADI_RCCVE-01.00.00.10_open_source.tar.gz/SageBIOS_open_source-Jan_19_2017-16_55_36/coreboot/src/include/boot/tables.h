#ifndef BOOT_TABLES_H
#define BOOT_TABLES_H

#include <boot/coreboot_tables.h>

void write_tables(void);

#endif /* BOOT_TABLES_H */
