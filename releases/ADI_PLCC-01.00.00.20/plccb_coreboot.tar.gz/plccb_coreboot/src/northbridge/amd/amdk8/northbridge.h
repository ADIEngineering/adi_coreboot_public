#ifndef NORTHBRIDGE_AMD_AMDK8_H
#define NORTHBRIDGE_AMD_AMDK8_H

extern unsigned int amdk8_scan_root_bus(device_t root, unsigned int max);

#endif /* NORTHBRIDGE_AMD_AMDK8_H */
